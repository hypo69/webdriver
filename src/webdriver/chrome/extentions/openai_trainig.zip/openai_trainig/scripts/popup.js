// Инициализируем Angular приложение
const app = angular.module('openaiApp', []);

// Контроллер для обработки логики
app.controller('MainController', function ($scope, $http) {
    $scope.message = '';
    $scope.response = '';
    $scope.assistants = [];
    $scope.selectedAssistant = null;
    $scope.trainingData = '';
    $scope.trainingStatus = '';
    $scope.activeTab = 'chat';  // По умолчанию активна вкладка "Chat"
    $scope.username = '';
    $scope.apiKey = '';
    $scope.settingsSaved = false;

    // Функция для переключения вкладок
    $scope.setActiveTab = function (tab) {
        $scope.activeTab = tab;
    };

    // Проверка активной вкладки
    $scope.isTabActive = function (tab) {
        return $scope.activeTab === tab;
    };

    // Функция для получения списка ассистентов
    function loadAssistants() {
        const url = 'http://localhost:8000/assistants';  // Адрес FastAPI для получения списка ассистентов
        $http.get(url)
            .then(function (response) {
                $scope.assistants = response.data;  // Список ассистентов
            })
            .catch(function (error) {
                console.error('Ошибка загрузки ассистентов:', error);
            });
    }

    // Загружаем список ассистентов при инициализации
    loadAssistants();

    // Функция для отправки сообщения модели
    $scope.sendMessage = function () {
        const url = 'http://localhost:8000/ask';  // Адрес FastAPI для отправки запроса

        const data = {
            message: $scope.message,
            system_instruction: "You are a helpful assistant.",
            assistant_id: $scope.selectedAssistant ? $scope.selectedAssistant.id : null  // Добавляем ID ассистента
        };

        // Отправка POST-запроса через $http (AJAX)
        $http.post(url, data)
            .then(function (response) {
                $scope.response = response.data.response;  // Ответ от сервера
            })
            .catch(function (error) {
                console.error('Ошибка:', error);
                $scope.response = 'Произошла ошибка. Попробуйте позже.';
            });
    };

    // Функция для обучения модели
    $scope.trainModel = function () {
        const url = 'http://localhost:8000/train';  // Адрес FastAPI для обучения модели

        const data = {
            data: $scope.trainingData
        };

        $http.post(url, data)
            .then(function (response) {
                $scope.trainingStatus = 'Training started, job ID: ' + response.data.job_id;  // Статус обучения
            })
            .catch(function (error) {
                console.error('Ошибка:', error);
                $scope.trainingStatus = 'Произошла ошибка при запуске обучения.';
            });
    };

    // Функция для сохранения настроек
    $scope.saveSettings = function () {
        // Логика сохранения настроек, здесь просто устанавливаем флаг успешного сохранения
        $scope.settingsSaved = true;

        // Например, можно отправить данные на сервер
        const settingsData = {
            username: $scope.username,
            apiKey: $scope.apiKey
        };

        $http.post('http://localhost:8000/save-settings', settingsData)
            .then(function (response) {
                console.log('Settings saved successfully');
            })
            .catch(function (error) {
                console.error('Ошибка сохранения настроек:', error);
            });
    };
});
